package com.backup.restore;

public class SMSGettersSetters {
    String _address;
    String _body;
    String _date;
    String _date_sent;
    String _delivery_date;
    String _id;
    String _person;
    String _read;
    String _thread_id;
    String _type;

    public String getAddress() {
        return this._address;
    }

    public String getBody() {
        return this._body;
    }

    public String getDate() {
        return this._date;
    }

    public String getDelveryDate() {
        return this._delivery_date;
    }

    public String getId() {
        return this._id;
    }

    public String getPerson() {
        return this._person;
    }

    public String getRead() {
        return this._read;
    }

    public String getSentDate() {
        return this._date_sent;
    }

    public String getThreadId() {
        return this._thread_id;
    }

    public String getType() {
        return this._type;
    }

    public void setAddres(String paramString) {
        this._address = paramString;
    }

    public void setBody(String paramString) {
        this._body = paramString;
    }

    public void setDate(String paramString) {
        this._date = paramString;
    }

    public void setDelveryDate(String paramString) {
        this._delivery_date = paramString;
    }

    public void setId(String paramString) {
        this._id = paramString;
    }

    public void setPerson(String paramString) {
        this._person = paramString;
    }

    public void setRead(String paramString) {
        this._read = paramString;
    }

    public void setSentDate(String paramString) {
        this._date_sent = paramString;
    }

    public void setThreadId(String paramString) {
        this._thread_id = paramString;
    }

    public void setType(String paramString) {
        this._type = paramString;
    }
}
