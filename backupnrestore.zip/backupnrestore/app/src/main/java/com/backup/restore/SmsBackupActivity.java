package com.backup.restore;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.BaseColumns;
import android.provider.Telephony.Sms;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import android.text.Html;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class SmsBackupActivity extends Activity {
    private static final int DEF_SMS_REQ = 0;
    public static final String KEY_ADDRESS = "address";
    public static final String KEY_BODY = "body";
    public static final String KEY_DATE = "date";
    public static final String KEY_ID = "id";
    public static final String KEY_PERSON = "person";
    public static final String KEY_READ = "read";
    public static final String KEY_THRED_ID = "threadId";
    public static final String KEY_TYPE = "type";
    private static Context context;
    public String str;
    Button btnBackup;
    Button btnDeleteAllMessages;
    Button btnRestore;
    Button btnSendToEmail;
    Button btnViewBackups;
    String dPak;
    AlertDialog dismiss;
    int i;
    int j;
    ArrayList localArrayList;
    Cursor localCursor;
    SMSGettersSetters localSMSGettersSetters;
    Uri localUri;
    ProgressDialog pDialog;
    public List<SMSGettersSetters> smsBuffer = new ArrayList();
    TextView tvLastBackup;
    FileWriter write;
    String[] xmlfile;

    public class DeletingSMSTask extends AsyncTask<Void, Void, Void> {
        public ProgressDialog pd = new ProgressDialog(SmsBackupActivity.this);

        public DeletingSMSTask(SmsBackupActivity smsBackupActivity) {
        }

        protected Void doInBackground(Void[] paramArrayOfVoid) {
            SmsBackupActivity.this.deleteAllSMS();
            return null;
        }

        protected void onPostExecute(Void paramVoid) {
            super.onPostExecute(paramVoid);
            this.pd.dismiss();
            ((TextView) SmsBackupActivity.this.findViewById(R.id.tvSMS)).setText(Html.fromHtml("<font color='#FFFFFF'>SMS:</font>" + SmsBackupActivity.this.getSMSCount()));
            Toast.makeText(SmsBackupActivity.this.getApplicationContext(), "SMS Deleted Successfully!", Toast.LENGTH_SHORT).show();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.pd.setMessage(SmsBackupActivity.this.getString(R.string.deleting_all_sms_));
            this.pd.show();
        }
    }

    public class RestoringTask extends AsyncTask<String, Integer, String> {
        Integer[] arrayOfInteger;
        ProgressDialog pd = new ProgressDialog(SmsBackupActivity.this);

        public RestoringTask(SmsBackupActivity smsBackupActivity) {
        }

        protected String doInBackground(String[] paramArrayOfString) {
            //Log.e("File", paramArrayOfString[0]);
            String str = SmsBackupActivity.this.getXML(paramArrayOfString[0]);
            XMLParser localXMLParser = new XMLParser();
            NodeList localNodeList = localXMLParser.getDomElement(str).getElementsByTagName("sms");
            int i = localNodeList.getLength();
            for (int j = 0; j < i; j++) {
                HashMap localHashMap = new HashMap();
                Element localElement = (Element) localNodeList.item(j);
                localHashMap.put("id", localXMLParser.getValue(localElement, "id"));
                localHashMap.put(SmsBackupActivity.KEY_THRED_ID, localXMLParser.getValue(localElement, SmsBackupActivity.KEY_THRED_ID));
                localHashMap.put(SmsBackupActivity.KEY_ADDRESS, localXMLParser.getValue(localElement, SmsBackupActivity.KEY_ADDRESS));
                localHashMap.put("person", localXMLParser.getValue(localElement, "person"));
                localHashMap.put("date", localXMLParser.getValue(localElement, "date"));
                localHashMap.put(SmsBackupActivity.KEY_BODY, localXMLParser.getValue(localElement, SmsBackupActivity.KEY_BODY));
                localHashMap.put("type", localXMLParser.getValue(localElement, "type"));
                localHashMap.put(SmsBackupActivity.KEY_READ, localXMLParser.getValue(localElement, SmsBackupActivity.KEY_READ));
                SmsBackupActivity.this.restoreBackup(localHashMap);
                publishProgress(new Integer[]{Integer.valueOf(i), Integer.valueOf(j)});
            }
            return "";
        }

        @SuppressLint({"InlinedApi"})
        protected void onPostExecute(String paramString) {
            super.onPostExecute(paramString);
            ((TextView) SmsBackupActivity.this.findViewById(R.id.tvSMS)).setText(Html.fromHtml("<font color='#FFFFFF'>SMS:</font>" + SmsBackupActivity.this.getSMSCount()));
           // this.pd.dismiss();
            if (VERSION.SDK_INT >= 19) {
                Toast.makeText(SmsBackupActivity.this.getApplicationContext(), "Restore Succesfully", Toast.LENGTH_SHORT).show();
                Toast.makeText(SmsBackupActivity.this.getApplicationContext(), "Set Your Default Messanger App", Toast.LENGTH_SHORT).show();
                SmsBackupActivity.this.startActivityForResult(new Intent("android.settings.WIRELESS_SETTINGS"), 0);
                return;
            }
            SmsBackupActivity.this.viewMessagesDialog();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.pd.setProgressStyle(1);
            this.pd.setMessage(SmsBackupActivity.this.getString(R.string.restoring_backups_));
            this.pd.setProgressDrawable(SmsBackupActivity.this.getResources().getDrawable(R.drawable.greenprogress));
//            this.pd.show();
        }

        protected void onProgressUpdate(Integer[] paramArrayOfInteger) {
            this.pd.setMax(paramArrayOfInteger[0].intValue());
            this.pd.setProgress(paramArrayOfInteger[1].intValue());
            super.onProgressUpdate(paramArrayOfInteger);
        }
    }

    private void backupSMS() throws IOException {
        this.smsBuffer.clear();
        String str1 = Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "sms";
        this.write = new FileWriter(str1 + File.separator + this.xmlfile[0] + ".xml");
        this.localUri = Uri.parse("content://sms/");
        this.localCursor = getContentResolver().query(this.localUri, new String[]{BaseColumns._ID, "thread_id", KEY_ADDRESS, "person", "date", KEY_BODY, "type", KEY_READ}, null, null, null);
        String[] arrayOfString2 = new String[]{BaseColumns._ID, "thread_id", KEY_ADDRESS, "person", "date", KEY_BODY, "type", KEY_READ};
        this.localCursor.moveToFirst();
        this.i = this.localCursor.getCount();
        this.pDialog.setMax(this.i);
        this.write.append("<?xml version='1.0' encoding='UTF-8'?>");
        this.write.append('\n');
        this.write.append("<smsall>");
        this.write.append('\n');
        do {
            this.localSMSGettersSetters = new SMSGettersSetters();
            String str2 = this.localCursor.getString(this.localCursor.getColumnIndex(BaseColumns._ID));
            String str3 = this.localCursor.getString(this.localCursor.getColumnIndex("thread_id"));
            String str4 = this.localCursor.getString(this.localCursor.getColumnIndex(KEY_ADDRESS));
            String str5 = this.localCursor.getString(this.localCursor.getColumnIndex("person"));
            String str6 = this.localCursor.getString(this.localCursor.getColumnIndex("date"));
            String str7 = this.localCursor.getString(this.localCursor.getColumnIndex(KEY_BODY)).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll(">", "&apos;").replaceAll("'", "&frasl;");
            String str8 = this.localCursor.getString(this.localCursor.getColumnIndex("type"));
            String str9 = this.localCursor.getString(this.localCursor.getColumnIndex(KEY_READ));
            this.localSMSGettersSetters.setId(str2);
            this.localSMSGettersSetters.setThreadId(str3);
            this.localSMSGettersSetters.setAddres(str4);
            this.localSMSGettersSetters.setPerson(str5);
            this.localSMSGettersSetters.setDate(str6);
            this.localSMSGettersSetters.setBody(str7);
            this.localSMSGettersSetters.setType(str8);
            this.localSMSGettersSetters.setRead(str9);
            this.localSMSGettersSetters.setSentDate(str1);
            this.smsBuffer.add(this.localSMSGettersSetters);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                public void run() {
                    int m = SmsBackupActivity.this.j;
                    SmsBackupActivity.this.pDialog.setProgress(m + 1);
                    SmsBackupActivity smsBackupActivity = SmsBackupActivity.this;
                    smsBackupActivity.i++;
                    if (m == SmsBackupActivity.this.i - 1) {
                        Log.d("dismiss", "is called");
                        SmsBackupActivity.this.pDialog.dismiss();
                        SmsBackupActivity.this.setBackupDate();
                        SmsBackupActivity.this.setEmailDialog();
                    }
                    smsBackupActivity = SmsBackupActivity.this;
                    smsBackupActivity.i--;
                }
            });
            generateXMLFileForSMS(this.localSMSGettersSetters);
            this.localCursor.moveToNext();
            this.j++;
        } while (this.j != this.i);
        this.write.append("</smsall>");
        this.write.flush();
        this.write.close();
        this.pDialog.dismiss();
    }

    private void generateXMLFileForSMS(SMSGettersSetters paramSMSGettersSetters) {
        try {
            this.write.append("<sms>");
            this.write.append('\n');
            this.write.append("<id>" + paramSMSGettersSetters.getId() + "</id>");
            this.write.append('\n');
            this.write.append("<threadId>" + paramSMSGettersSetters.getThreadId() + "</threadId>");
            this.write.append('\n');
            this.write.append("<address>" + paramSMSGettersSetters.getAddress() + "</address>");
            this.write.append('\n');
            this.write.append("<person>" + paramSMSGettersSetters.getPerson() + "</person>");
            this.write.append('\n');
            this.write.append("<date>" + paramSMSGettersSetters.getDate() + "</date>");
            this.write.append('\n');
            this.write.append("<body>" + paramSMSGettersSetters.getBody() + "</body>");
            this.write.append('\n');
            this.write.append("<type>" + paramSMSGettersSetters.getType() + "</type>");
            this.write.append('\n');
            this.write.append("<read>" + paramSMSGettersSetters.getRead() + "</read>");
            this.write.append('\n');
            this.write.append("</sms>");
            this.write.append('\n');
        } catch (NullPointerException localNullPointerException) {
            while (true) {
                System.out.println("Nullpointer Exception " + localNullPointerException);
            }
        } catch (IOException localIOException) {
            while (true) {
                localIOException.printStackTrace();
            }
        } catch (Exception localException) {
            while (true) {
                localException.printStackTrace();
            }
        }
    }

    @SuppressLint("WrongConstant")
    private void launchComponent(String paramString1, String paramString2) {
        Intent localIntent = new Intent("android.intent.action.MAIN");
        localIntent.addCategory("android.intent.category.LAUNCHER");
        localIntent.setComponent(new ComponentName(paramString1, paramString2));
        localIntent.setFlags(268435456);
        startActivity(localIntent);
    }

    public void BackupAlert() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.app_name));
        View localView = getLayoutInflater().inflate(R.layout.layout_backup_dialog, null);
        final EditText localEditText = (EditText) localView.findViewById(R.id.etFileName);
        localEditText.setText("sms_" + DateFormat.format("yyMMddhhmmss", new Date().getTime()) + ".xml");
        localBuilder.setView(localView);
        localBuilder.setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                SmsBackupActivity.this.xmlfile = localEditText.getText().toString().trim().split(".xml");
                SmsBackupActivity.this.setProgressDialog();
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            Looper.prepare();
                            SmsBackupActivity.this.backupSMS();
                            Looper.loop();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        localAlertDialog.show();
    }

    public void deleteAllSMS() {
        Cursor localCursor = getContentResolver().query(Uri.parse("content://sms/"), null, null, null, null);
        while (localCursor.moveToNext()) {
            try {
                localCursor.getString(0);
                getContentResolver().delete(Uri.parse("content://sms/"), null, null);
            } catch (Exception e) {
            }
        }
    }

    public void deleteAllSMSDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setMessage("Are you sure you wan to delete all the SMS on the phone?");
        localBuilder.setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                SmsBackupActivity.this.panicDialog();
            }
        });
        localBuilder.setNegativeButton("Cancel", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localBuilder.show();
    }

    public String getBackupDate(String paramString) {
        return getSharedPreferences("BackupPrefs", 0).getString(paramString, getString(R.string.never_backup));
    }

    public int getSMSCount() {
        //Cursor localCursor;

            Cursor localCursor = getContentResolver().query(Uri.parse("content://sms/"), null, null, null, null);
            String[] arrayOfString = localCursor.getColumnNames();
            for (String d : arrayOfString) {
                Log.d("Names are", d);
            }
        return localCursor.getCount();
    }

    public List<FileGetterSetters> getSMSFiles() {
        localArrayList = new ArrayList();
        int i=0;
        for (File localFile : new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "sms").listFiles()) {
            FileGetterSetters localFileGetterSetters = new FileGetterSetters();
            Log.d("file Name is", localFile.getName());
            localFileGetterSetters.setFileName(localFile.getName());
            Date localDate = new Date(localFile.lastModified());
            Log.d("Modified date is", localDate.toString());
            localFileGetterSetters.setDateCreated(localDate.toString());
            localArrayList.add(localFileGetterSetters);
            i++;
        }
        if(i==0){
            FileGetterSetters localFileGetterSetters = new FileGetterSetters();
            localFileGetterSetters.setFileName("Backup File Not Found");
            localFileGetterSetters.setDateCreated("noDate");
            localArrayList.add(localFileGetterSetters);
        }
        return localArrayList;
    }

    public String getXML(String paramString) {
        Log.e("File path is", paramString);
        Log.d("File path is", paramString);
        File localFile = new File(paramString);
        StringBuilder localStringBuilder = new StringBuilder();
        try {
            BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(localFile)));
            while (true) {
                String str = localBufferedReader.readLine();
                if (str == null) {
                    return localStringBuilder.toString();
                }
                localStringBuilder.append(str);
                localStringBuilder.append('\n');
            }
        } catch (IOException e) {
            return paramString;
        }
    }

    public void initAllViews() {
        this.btnBackup = (Button) findViewById(R.id.btnBackup);
        this.btnRestore = (Button) findViewById(R.id.btnRestore);
        this.btnViewBackups = (Button) findViewById(R.id.btnViewBackup);
        this.btnSendToEmail = (Button) findViewById(R.id.btnSendToEmail);
        this.btnDeleteAllMessages = (Button) findViewById(R.id.btnDeleteAllMessages);
        TextView localTextView1 = (TextView) findViewById(R.id.tvSMS);
        this.tvLastBackup = (TextView) findViewById(R.id.tvLastBackup);
        TextView localTextView2 = (TextView) findViewById(R.id.tvTitle);
        Typeface localTypeface = Typeface.createFromAsset(getAssets(), "nexalight.otf");
        this.btnBackup.setTypeface(localTypeface);
        this.btnRestore.setTypeface(localTypeface);
        this.btnViewBackups.setTypeface(localTypeface);
        this.btnSendToEmail.setTypeface(localTypeface);
        this.btnDeleteAllMessages.setTypeface(localTypeface);
        localTextView2.setTypeface(localTypeface);
        localTextView1.setTypeface(localTypeface);
        this.tvLastBackup.setTypeface(localTypeface);
        this.btnBackup.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (SmsBackupActivity.this.getSMSCount() > 0) {

                    SmsBackupActivity.this.BackupAlert();
                } else {
                    Toast.makeText(SmsBackupActivity.this.getApplicationContext(), "No Backup Found", Toast.LENGTH_SHORT).show();
                }
            }
        });
        this.btnRestore.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (VERSION.SDK_INT >= 19) {
                    String myPackageName = SmsBackupActivity.this.getPackageName();
                    if (Sms.getDefaultSmsPackage(SmsBackupActivity.this.getApplicationContext()).equals(myPackageName)) {
                        Toast.makeText(SmsBackupActivity.this.getApplicationContext(), "Set Your Default Messanger App", Toast.LENGTH_SHORT).show();
                        SmsBackupActivity.this.startActivityForResult(new Intent("android.settings.WIRELESS_SETTINGS"), 0);
                        return;
                    }
                    Intent intent = new Intent("android.provider.Telephony.ACTION_CHANGE_DEFAULT");
                    intent.putExtra("package", myPackageName);
                    SmsBackupActivity.this.startActivityForResult(intent, 0);
                    return;
                }
                SmsBackupActivity.this.restoreBackupFilesDialog(true);
            }
        });
        this.btnViewBackups.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SmsBackupActivity.this.showBackupFilesDialog(false);
            }
        });
        this.btnSendToEmail.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SmsBackupActivity.this.showBackupFilesDialog(true);
            }
        });
        this.btnDeleteAllMessages.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SmsBackupActivity.this.deleteAllSMSDialog();
            }
        });
        localTextView1.setText(Html.fromHtml("<font color='#FFFFFF'>SMS:</font>" + getSMSCount()));
        this.tvLastBackup.setText(Html.fromHtml("<font color='#FFFFFF'>" + getString(R.string.last_backup) + ":</font>" + getBackupDate("smsBackupDate")));
    }

    public void okDialog() {
        AlertDialog localAlertDialog = new Builder(this).create();
        localAlertDialog.setTitle(getString(R.string.app_name));
        localAlertDialog.setMessage(getString(R.string.deleted_successfully_));
        localAlertDialog.setButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localAlertDialog.show();
    }

    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setContentView(R.layout.layout_sms_backup);
        context = getApplicationContext();
        initAllViews();

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 0:
                if ((VERSION.SDK_INT == 19 && isDefaultSmsApp(this)) || (VERSION.SDK_INT >= 21 && resultCode == -1)) {
                    restoreBackupFilesDialog(true);
                    return;
                }
                return;
            default:
                return;
        }
    }

    @TargetApi(19)
    public static boolean isDefaultSmsApp(Context context) {
        return context.getPackageName().equals(Sms.getDefaultSmsPackage(context));
    }

    @SuppressLint("WrongConstant")
    public void openInbox() {
        try {
            Intent localIntent = new Intent("android.intent.action.MAIN");
            localIntent.addCategory("android.intent.category.LAUNCHER");
            localIntent.addFlags(AccessibilityEventCompat.TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED);
            for (ResolveInfo localResolveInfo : getPackageManager().queryIntentActivities(localIntent, 0)) {
                if (localResolveInfo.activityInfo.packageName.equalsIgnoreCase("com.android.mms")) {
                    launchComponent(localResolveInfo.activityInfo.packageName, localResolveInfo.activityInfo.name);
                }
            }
        } catch (ActivityNotFoundException e) {
            Toast.makeText(getApplicationContext(), getString(R.string.there_was_a_problem_loading_the_application_) + "com.android.mms", Toast.LENGTH_SHORT).show();
        }
    }

    public void panicDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setMessage("Are you sure you wan to delete all the SMS on the phone?");
        localBuilder.setPositiveButton("Sure", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                new DeletingSMSTask(SmsBackupActivity.this).execute(new Void[0]);
            }
        });
        localBuilder.setNegativeButton("Cancel", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localBuilder.show();
    }

    public void restoreBackup(HashMap<String, String> paramHashMap) {
        ContentValues localContentValues = new ContentValues();
        localContentValues.put(KEY_ADDRESS, (String) paramHashMap.get(KEY_ADDRESS));
        localContentValues.put("person", (String) paramHashMap.get("person"));
        localContentValues.put("date", (String) paramHashMap.get("date"));
        localContentValues.put(KEY_BODY, (String) paramHashMap.get(KEY_BODY));
        localContentValues.put(BaseColumns._ID, (String) paramHashMap.get("id"));
        localContentValues.put("type", (String) paramHashMap.get("type"));
        localContentValues.put(KEY_READ, (String) paramHashMap.get(KEY_READ));
        if (VERSION.SDK_INT >= 21) {
            getContentResolver().insert(Sms.CONTENT_URI, localContentValues);
        } else {
            getContentResolver().insert(Uri.parse("content://sms/"), localContentValues);
        }
    }

    public void restoreBackupFilesDialog(final boolean paramBoolean) {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.backup_files);
        ListView localListView = new ListView(this);
        final List localList = getSMSFiles();
        localListView.setAdapter(new FileAdapter(this, R.layout.item_row_file, localList));
        localListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong) {
                SmsBackupActivity.this.dismiss.dismiss();
                if (paramBoolean) {
                    Log.d("Seleted file path is", Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "sms" + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName());
                    Log.e("file", Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "sms" + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName());
                    String str=Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "sms" + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName();
                    File file = new File(str);
                    if(file.exists()) {
                        new RestoringTask(SmsBackupActivity.this).execute(new String[]{str});
                    }else{

                    }
                }
            }
        });
        localBuilder.setView(localListView);
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().alpha = 0.6f;
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.FileDialogAnimation;
        this.dismiss = localAlertDialog;
        localAlertDialog.show();
    }

    public void sendFileToEmail(String paramString) {
        Intent localIntent = new Intent("android.intent.action.SEND");
        localIntent.setType("message/rfc822");
        localIntent.putExtra("android.intent.extra.EMAIL", new String[0]);
        localIntent.putExtra("android.intent.extra.SUBJECT", "");
        localIntent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + paramString));
        localIntent.putExtra("android.intent.extra.TEXT", "");
        startActivity(Intent.createChooser(localIntent, "Send mail..."));
    }

    public void setBackupDate() {
        CharSequence localCharSequence = DateFormat.format("yy/MM/dd hh:mm:ss", new Date().getTime());
        this.tvLastBackup.setText(Html.fromHtml("<font color='#FFFFFF'>" + getString(R.string.last_backup) + ":</font>" + localCharSequence.toString()));
        setLastBackupDate("smsBackupDate", localCharSequence.toString());
    }

    public void setEmailDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setCancelable(false);
        localBuilder.setMessage(getString(R.string.send_to_email_backup) + "?");
        localBuilder.setNegativeButton("Back", new OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(DialogInterface dialog, int which) {
                Intent inn = new Intent(SmsBackupActivity.this.getApplicationContext(), MainActivity.class);
                inn.setFlags(67108864);
                SmsBackupActivity.this.startActivity(inn);
            }
        });
        localBuilder.create().show();
    }

    public void setLastBackupDate(String paramString1, String paramString2) {
        Editor localEditor = getSharedPreferences("BackupPrefs", 0).edit();
        localEditor.putString(paramString1, paramString2);
        localEditor.commit();
    }

    public void setProgressDialog() {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setMessage(getString(R.string.backuping_files_please_wait_));
        this.pDialog.setIndeterminate(false);
        this.pDialog.setProgressDrawable(getResources().getDrawable(R.drawable.greenprogress));
        this.pDialog.setMax(100);
        this.pDialog.setProgressStyle(1);
        this.pDialog.setCancelable(true);
        this.pDialog.show();
    }

    public void showBackupFilesDialog(final boolean paramBoolean) {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.backup_files));
        ListView localListView = new ListView(this);
        final List localList = getSMSFiles();
        final ArrayList<FileGetterSetters> localList1 = (ArrayList<FileGetterSetters>) getSMSFiles();
        localListView.setAdapter(new FileAdapter(this, R.layout.item_row_file, localList));
       // Log.e("file",localList1.get(0).getFileName());
        if(localList1.get(0).getFileName()!="Backup File Not Found") {
            localListView.setOnItemClickListener(new OnItemClickListener() {
                public void onItemClick(AdapterView<?> adapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong) {
                    SmsBackupActivity.this.dismiss.dismiss();
                    if (paramBoolean) {
                        SmsBackupActivity.this.sendFileToEmail(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "sms" + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName());
                    }
                }
            });
        }
        localBuilder.setView(localListView);
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().alpha = 0.6f;
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.FileDialogAnimation;
        this.dismiss = localAlertDialog;
        localAlertDialog.show();
    }

    public void viewMessagesDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.app_name));
        localBuilder.setMessage(getString(R.string.restore_completed_successfully_));
        localBuilder.setPositiveButton(getString(R.string.view_messages), new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                SmsBackupActivity.this.openInbox();
            }
        });
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        localAlertDialog.show();
    }
}
