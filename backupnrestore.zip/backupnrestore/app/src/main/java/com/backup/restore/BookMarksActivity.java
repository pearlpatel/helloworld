package com.backup.restore;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.BaseColumns;
import android.provider.Browser;
import android.text.Html;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import a_vcard.android.syncml.pim.vcard.VCardParser_V21;

@SuppressLint({"NewApi"})
public class BookMarksActivity extends Activity {
    private static final String ALLOWED_URI_CHARS = "@#&=*+-_.,:!?()/~'%";
    public static final String KEY_BOOKMARK = "bookmark";
    public static final String KEY_DATE = "date";
    public static final String KEY_FAVICON = "favicon";
    public static final String KEY_ID = "id";
    public static final String KEY_THUMBNAIL = "thumbnail";
    public static final String KEY_TITLE = "title";
    public static final String KEY_TOUCH_ICON = "touch_icon";
    public static final String KEY_URL = "url";
    public static final String KEY_USER_ENTERED = "user_entered";
    public static final String KEY_VISITS = "visits";
    public String str;
    Button btnBackup;
    Button btnDeleteAllBookMarks;
    Button btnRestore;
    Button btnSendToEmail;
    Button btnViewBackups;
    AlertDialog dismiss;
    String encodedImage;
    int i;
    int j;
    BookmarksGettersSetters localBookmarksGettersSetters;
    Cursor localCursor;
    ProgressDialog pDialog;
    TextView tvLastBackup;
    FileWriter write;
    String[] xmlfile;

    public class DeletingBookmarksTask extends AsyncTask<Void, Void, Void> {
        public ProgressDialog pd = new ProgressDialog(BookMarksActivity.this);

        protected Void doInBackground(Void[] paramArrayOfVoid) {
            BookMarksActivity.this.deleteAllBookmarks();
            return null;
        }

        protected void onPostExecute(Void paramVoid) {
            super.onPostExecute(paramVoid);
            this.pd.dismiss();
            ((TextView) BookMarksActivity.this.findViewById(R.id.tvBookmarks)).setText(Html.fromHtml("<font color='#FFFFFF'>Bookmarks:</font>" + BookMarksActivity.this.getBookmarksCount()));
            Toast.makeText(BookMarksActivity.this.getApplicationContext(), R.string.bookmarks_deleted_successfully_, Toast.LENGTH_SHORT).show();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.pd.setMessage(BookMarksActivity.this.getString(R.string.deleting_all_bookmarks_));
            this.pd.show();
        }
    }

    @SuppressLint({"NewApi"})
    public class RestoringTask extends AsyncTask<String, Integer, String> {
        ProgressDialog pd = new ProgressDialog(BookMarksActivity.this);

        public RestoringTask(BookMarksActivity bookMarksActivity) {
        }

        protected String doInBackground(String[] paramArrayOfString) {
            String str = BookMarksActivity.this.getXML(paramArrayOfString[0]);
            XMLParser localXMLParser = new XMLParser();
            NodeList localNodeList = localXMLParser.getDomElement(str).getElementsByTagName("bookmarks");
            int i = localNodeList.getLength();
            for (int j = 0; j < i; j++) {
                HashMap localHashMap = new HashMap();
                Element localElement = (Element) localNodeList.item(j);
                localHashMap.put("url", localXMLParser.getValue(localElement, "url"));
                localHashMap.put(BookMarksActivity.KEY_VISITS, localXMLParser.getValue(localElement, BookMarksActivity.KEY_VISITS));
                localHashMap.put("date", localXMLParser.getValue(localElement, "date"));
                localHashMap.put(BookMarksActivity.KEY_BOOKMARK, localXMLParser.getValue(localElement, BookMarksActivity.KEY_BOOKMARK));
                localHashMap.put("title", localXMLParser.getValue(localElement, "title"));
                BookMarksActivity.this.restoreBackup(localHashMap);
                publishProgress(new Integer[]{Integer.valueOf(i), Integer.valueOf(j)});
            }
            return "";
        }

        protected void onPostExecute(String paramString) {
            super.onPostExecute(paramString);
            ((TextView) BookMarksActivity.this.findViewById(R.id.tvBookmarks)).setText(Html.fromHtml("<font color='#FFFFFF'>Bookmarks:</font>" + BookMarksActivity.this.getBookmarksCount()));
            this.pd.dismiss();
            BookMarksActivity.this.viewBookmarksDialog();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.pd.setProgressStyle(1);
            this.pd.setMessage(BookMarksActivity.this.getString(R.string.restoring_backups_));
            this.pd.setProgressDrawable(BookMarksActivity.this.getResources().getDrawable(R.drawable.greenprogress));
            this.pd.show();
        }

        protected void onProgressUpdate(Integer[] paramArrayOfInteger) {
            this.pd.setMax(paramArrayOfInteger[0].intValue());
            this.pd.setProgress(paramArrayOfInteger[1].intValue());
            super.onProgressUpdate(paramArrayOfInteger);
        }
    }

    private void backBookmarks() throws IOException {
        this.write = new FileWriter((Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "bookmarks") + File.separator + this.xmlfile[0] + ".xml");
        Uri localUri = Utils.BOOKMARKS_URI;
        this.localCursor = getContentResolver().query(localUri, new String[]{BaseColumns._ID, "url", KEY_VISITS, "date", KEY_BOOKMARK, "title", KEY_FAVICON, KEY_THUMBNAIL, KEY_TOUCH_ICON, KEY_USER_ENTERED}, null, null, null);
        String[] arrayOfString2 = new String[]{BaseColumns._ID, "url", KEY_VISITS, "date", KEY_BOOKMARK, "title", KEY_FAVICON, KEY_THUMBNAIL, KEY_TOUCH_ICON, KEY_USER_ENTERED};
        this.localCursor.moveToFirst();
        this.i = this.localCursor.getCount();
        this.pDialog.setMax(this.i);
        this.write.append("<?xml version='1.0' encoding='UTF-8'?>");
        this.write.append('\n');
        this.write.append("<allBookmarks>");
        this.write.append('\n');
        do {
            this.localBookmarksGettersSetters = new BookmarksGettersSetters();
            String str3 = this.localCursor.getString(this.localCursor.getColumnIndex("url"));
            String str4 = this.localCursor.getString(this.localCursor.getColumnIndex(KEY_VISITS));
            String str5 = this.localCursor.getString(this.localCursor.getColumnIndex("date"));
            String str6 = this.localCursor.getString(this.localCursor.getColumnIndex(KEY_BOOKMARK));
            String str7 = this.localCursor.getString(this.localCursor.getColumnIndex("title"));
            if (str5 == null) {
                str5 = "0";
            }
            this.localBookmarksGettersSetters.setUrl(URLEncoder.encode(str3, VCardParser_V21.DEFAULT_CHARSET));
            this.localBookmarksGettersSetters.setVisits(str4);
            this.localBookmarksGettersSetters.setDate(str5);
            this.localBookmarksGettersSetters.setBookmark(str6);
            this.localBookmarksGettersSetters.settitle(str7);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                public void run() {
                    int m = BookMarksActivity.this.j;
                    BookMarksActivity.this.pDialog.setProgress(m + 1);
                    BookMarksActivity bookMarksActivity = BookMarksActivity.this;
                    bookMarksActivity.i++;
                    if (m == BookMarksActivity.this.i - 1) {
                        Log.d("dismiss", "is called");
                        BookMarksActivity.this.pDialog.dismiss();
                        BookMarksActivity.this.setBackupDate();
                        BookMarksActivity.this.setEmailDialog();
                    }
                    bookMarksActivity = BookMarksActivity.this;
                    bookMarksActivity.i--;
                }
            });
            generateXMLFileForBookmarks(this.localBookmarksGettersSetters);
            this.localCursor.moveToNext();
            this.j++;
        } while (this.j != this.i);
        this.write.append("</allBookmarks>");
        this.write.flush();
        this.write.close();
        this.pDialog.dismiss();
    }

    private void generateXMLFileForBookmarks(BookmarksGettersSetters paramBookmarksGettersSetters) {
        try {
            this.write.append("<bookmarks>");
            this.write.append('\n');
            this.write.append("<url>" + paramBookmarksGettersSetters.getUrl() + "</url>");
            this.write.append('\n');
            this.write.append("<visits>" + paramBookmarksGettersSetters.getVisits() + "</visits>");
            this.write.append('\n');
            this.write.append("<date>" + paramBookmarksGettersSetters.getDate() + "</date>");
            this.write.append('\n');
            this.write.append("<bookmark>" + paramBookmarksGettersSetters.getBookmark() + "</bookmark>");
            this.write.append('\n');
            this.write.append("<title>" + paramBookmarksGettersSetters.gettitle() + "</title>");
            this.write.append('\n');
            this.write.append("</bookmarks>");
            this.write.append('\n');
        } catch (NullPointerException localNullPointerException) {
            while (true) {
                System.out.println("Nullpointer Exception " + localNullPointerException);
            }
        } catch (IOException localIOException) {
            while (true) {
                localIOException.printStackTrace();
            }
        } catch (Exception localException) {
            while (true) {
                localException.printStackTrace();
            }
        }
    }

    public void BackupAlert() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        View localView = getLayoutInflater().inflate(R.layout.layout_backup_dialog, null);
        final EditText localEditText = (EditText) localView.findViewById(R.id.etFileName);
        ((TextView) localView.findViewById(R.id.tvBackupLocation)).setText("storage/sdcard0/smsContactsBackups/bookmarks");
        localEditText.setText("bookmarks_" + DateFormat.format("yyMMddhhmmss", new Date().getTime()) + ".xml");
        localBuilder.setView(localView);
        localBuilder.setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                BookMarksActivity.this.xmlfile = localEditText.getText().toString().trim().split(".xml");
                BookMarksActivity.this.setProgressDialog();
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            Looper.prepare();
                            BookMarksActivity.this.backBookmarks();
                            Looper.loop();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        localAlertDialog.show();
    }

    public void deleteAllBookmarks() {
        Cursor localCursor = getContentResolver().query(Utils.BOOKMARKS_URI, null, null, null, null);
        while (localCursor.moveToNext()) {
            try {
                localCursor.getString(0);
                getContentResolver().delete(Utils.BOOKMARKS_URI, null, null);
            } catch (Exception e) {
            }
        }
    }

    public void deleteAllBookmarksDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setMessage(R.string.are_you_sure_you_wan_to_delete_all_the_bookmarks_on_the_phone_);
        localBuilder.setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                BookMarksActivity.this.panicDialog();
            }
        });
        localBuilder.setNegativeButton("Cancel", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localBuilder.show();
    }

    public String getBackupDate(String paramString) {
        return getSharedPreferences("BackupPrefs", 0).getString(paramString, getString(R.string.never_backup));
    }

    public int getBookmarksCount() {
        Cursor localCursor = getContentResolver().query(Utils.BOOKMARKS_URI, null, null, null, null);
        String[] arrayOfString = localCursor.getColumnNames();
        for (String d : arrayOfString) {
            Log.d("Bookmarks", d);
        }
        return localCursor.getCount();
    }

    public List<FileGetterSetters> getBookmarksFiles() {
        ArrayList localArrayList = new ArrayList();
        for (File localFile : new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "bookmarks").listFiles()) {
            FileGetterSetters localFileGetterSetters = new FileGetterSetters();
            Log.d("file Name is", localFile.getName());
            localFileGetterSetters.setFileName(localFile.getName());
            Date localDate = new Date(localFile.lastModified());
            Log.d("Modified date is", localDate.toString());
            localFileGetterSetters.setDateCreated(localDate.toString());
            localArrayList.add(localFileGetterSetters);
        }
        return localArrayList;
    }

    public String getXML(String paramString) {
        Log.d("File path is", paramString);
        File localFile = new File(paramString);
        StringBuilder localStringBuilder = new StringBuilder();
        try {
            BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(localFile)));
            while (true) {
                String str = localBufferedReader.readLine();
                if (str == null) {
                    return localStringBuilder.toString();
                }
                localStringBuilder.append(str);
                localStringBuilder.append('\n');
            }
        } catch (IOException e) {
            return paramString;
        }
    }

    public void initAllViews() {
        this.btnBackup = (Button) findViewById(R.id.btnBackup);
        this.btnRestore = (Button) findViewById(R.id.btnRestore);
        this.btnViewBackups = (Button) findViewById(R.id.btnViewBackup);
        this.btnSendToEmail = (Button) findViewById(R.id.btnSendToEmail);
        this.btnDeleteAllBookMarks = (Button) findViewById(R.id.btnDeleteAllBookMarks);
        TextView localTextView1 = (TextView) findViewById(R.id.tvBookmarks);
        this.tvLastBackup = (TextView) findViewById(R.id.tvLastBackup);
        TextView localTextView2 = (TextView) findViewById(R.id.tvTitle);
        Typeface localTypeface = Typeface.createFromAsset(getAssets(), "nexalight.otf");
        this.btnBackup.setTypeface(localTypeface);
        this.btnRestore.setTypeface(localTypeface);
        this.btnViewBackups.setTypeface(localTypeface);
        this.btnSendToEmail.setTypeface(localTypeface);
        this.btnDeleteAllBookMarks.setTypeface(localTypeface);
        localTextView2.setTypeface(localTypeface);
        localTextView1.setTypeface(localTypeface);
        this.tvLastBackup.setTypeface(localTypeface);
        this.btnBackup.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (BookMarksActivity.this.getBookmarksCount() > 0) {
                    BookMarksActivity.this.BackupAlert();
                } else {
                    Toast.makeText(BookMarksActivity.this.getApplicationContext(), "No Bookmark Found", Toast.LENGTH_LONG).show();
                }
            }
        });
        this.btnRestore.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                BookMarksActivity.this.restoreBackupFilesDialog(true);
            }
        });
        this.btnViewBackups.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                BookMarksActivity.this.showBackupFilesDialog(false);
            }
        });
        this.btnSendToEmail.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                BookMarksActivity.this.showBackupFilesDialog(true);
            }
        });
        this.btnDeleteAllBookMarks.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                BookMarksActivity.this.deleteAllBookmarksDialog();
            }
        });
        localTextView1.setText(Html.fromHtml("<font color='#FFFFFF'>" + getString(R.string.bookmarks) + ":</font>" + getBookmarksCount()));
        this.tvLastBackup.setText(Html.fromHtml("<font color='#FFFFFF'>" + getString(R.string.last_backup) + ":</font>" + getBackupDate("bookmarksBackupDate")));
    }

    public void okDialog() {
        AlertDialog localAlertDialog = new Builder(this).create();
        localAlertDialog.setTitle(getString(R.string.app_name));
        localAlertDialog.setMessage(getString(R.string.deleted_successfully_));
        localAlertDialog.setButton(getString(R.string.OK), new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localAlertDialog.show();
    }

    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setContentView(R.layout.layout_bookmarks_backup);

        initAllViews();
    }

    public void panicDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setIcon(R.drawable.icon_warning);
        localBuilder.setMessage(R.string.are_you_sure_you_wan_to_delete_all_the_bookmarks_on_the_phone_);
        localBuilder.setPositiveButton("Sure", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                new DeletingBookmarksTask().execute(new Void[0]);
            }
        });
        localBuilder.setNegativeButton("Cancel", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localBuilder.show();
    }

    public void restoreBackup(HashMap<String, String> paramHashMap) {
        ContentValues localContentValues = new ContentValues();
        try {
            localContentValues.put("url", URLDecoder.decode((String) paramHashMap.get("url"), VCardParser_V21.DEFAULT_CHARSET));
            localContentValues.put(KEY_VISITS, (String) paramHashMap.get(KEY_VISITS));
            localContentValues.put("date", (String) paramHashMap.get("date"));
            localContentValues.put(KEY_BOOKMARK, (String) paramHashMap.get(KEY_BOOKMARK));
            localContentValues.put("title", (String) paramHashMap.get("title"));
            getContentResolver().insert(Utils.BOOKMARKS_URI, localContentValues);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public void restoreBackupFilesDialog(final boolean paramBoolean) {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.backup_files));
        ListView localListView = new ListView(this);
        final List localList = getBookmarksFiles();
        localListView.setAdapter(new FileAdapter(this, R.layout.item_row_file, localList));
        localListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong) {
                BookMarksActivity.this.dismiss.dismiss();
                if (paramBoolean) {
                    Log.d("Seleted file path is", Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "bookmarks" + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName());
                    new RestoringTask(BookMarksActivity.this).execute(new String[]{str});
                }
            }
        });
        localBuilder.setView(localListView);
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().alpha = 0.6f;
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.FileDialogAnimation;
        this.dismiss = localAlertDialog;
        localAlertDialog.show();
    }

    public void sendFileToEmail(String paramString) {
        Intent localIntent = new Intent("android.intent.action.SEND");
        localIntent.setType("message/rfc822");
        localIntent.putExtra("android.intent.extra.EMAIL", new String[0]);
        localIntent.putExtra("android.intent.extra.SUBJECT", "");
        localIntent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + paramString));
        localIntent.putExtra("android.intent.extra.TEXT", "");
        startActivity(Intent.createChooser(localIntent, "Send mail..."));
    }

    public void onDestroy() {
        super.onDestroy();
        if (this.localCursor != null) {
            this.localCursor.close();
        }
    }

    public void setBackupDate() {
        CharSequence localCharSequence = DateFormat.format("yy/MM/dd hh:mm:ss", new Date().getTime());
        this.tvLastBackup.setText(Html.fromHtml("<font color='#FFFFFF'>" + getString(R.string.last_backup) + ":</font>" + localCharSequence.toString()));
        setLastBackupDate("bookmarksBackupDate", localCharSequence.toString());
    }

    public void setEmailDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setCancelable(false);
        localBuilder.setMessage(getString(R.string.send_to_email_backup) + "?");
        localBuilder.setPositiveButton("Back", new OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                Intent inn = new Intent(BookMarksActivity.this.getApplicationContext(), MainActivity.class);
                inn.setFlags(67108864);
                BookMarksActivity.this.startActivity(inn);
            }
        });
        localBuilder.create().show();
    }

    public void setLastBackupDate(String paramString1, String paramString2) {
        Editor localEditor = getSharedPreferences("BackupPrefs", 0).edit();
        localEditor.putString(paramString1, paramString2);
        localEditor.commit();
    }

    public void setProgressDialog() {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setMessage(getString(R.string.backuping_files_please_wait_));
        this.pDialog.setIndeterminate(false);
        this.pDialog.setProgressDrawable(getResources().getDrawable(R.drawable.greenprogress));
        this.pDialog.setMax(100);
        this.pDialog.setProgressStyle(1);
        this.pDialog.setCancelable(true);
        this.pDialog.show();
    }

    public void showBackupFilesDialog(final boolean paramBoolean) {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.backup_files);
        ListView localListView = new ListView(this);
        final List localList = getBookmarksFiles();
        localListView.setAdapter(new FileAdapter(this, R.layout.item_row_file, localList));
        localListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong) {
                BookMarksActivity.this.dismiss.dismiss();
                if (paramBoolean) {
                    str = Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "bookmarks" + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName();
                    Log.i("a", str);
                    BookMarksActivity.this.sendFileToEmail(str);
                }
            }
        });
        localBuilder.setView(localListView);
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().alpha = 0.6f;
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.FileDialogAnimation;
        this.dismiss = localAlertDialog;
        localAlertDialog.show();
    }

    public void viewBookmarksDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setMessage(getString(R.string.restore_completed_successfully_));
        localBuilder.setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                BookMarksActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://www.google.com")));
            }
        });
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        localAlertDialog.show();
    }
}
