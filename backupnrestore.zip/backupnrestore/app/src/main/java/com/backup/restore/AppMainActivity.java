package com.backup.restore;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class AppMainActivity extends ListActivity {
    private List<ApplicationInfo> applist = null;
    boolean blo = true;
    Button btn1;
    private ApplicationAdapter listadaptor = null;
    private PackageManager packageManager = null;
    private ProgressDialog progressDialog;

    private class LoApplications1 extends AsyncTask<Void, Void, Void> {
        private ProgressDialog progress1;
        int position;

        private LoApplications1(int position) {
            this.progress1 = null;
            this.position=position;
        }

        protected Void doInBackground(Void... params) {
            try {
                Intent intent = packageManager.getLaunchIntentForPackage(((ApplicationInfo) applist.get(position)).packageName);
                if (intent != null) {
                    intent.addCategory("android.intent.category.LAUNCHER");
                    for (ResolveInfo info : getPackageManager().queryIntentActivities(intent, 0)) {
                        File f1 = new File(info.activityInfo.applicationInfo.publicSourceDir);
                        try {
                            String file_name = info.loadLabel(getApplicationContext().getPackageManager()).toString();
                            File f2 = new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "App");
                            f2.mkdirs();
                            File f22 = new File(f2.getPath() + "/" + file_name + ".apk");
                            f22.createNewFile();
                            InputStream in = new FileInputStream(f1);
                            OutputStream out = new FileOutputStream(f22);
                            byte[] buf = new byte[1024];
                            while (true) {
                                int len = in.read(buf);
                                if (len <= 0) {
                                    break;
                                }
                                out.write(buf, 0, len);
                            }
                            in.close();
                            out.close();
                            System.out.println("File copied.");
                        } catch (FileNotFoundException ex) {
                            System.out.println(ex.getMessage() + " in the specified directory.");
                        } catch (IOException e) {
                            System.out.println(e.getMessage());
                        }
                    }
                }
                // progress1.dismiss();
            } catch (ActivityNotFoundException e) {
                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
            } catch (Exception e2) {
                Toast.makeText(getApplicationContext(), e2.getMessage(), Toast.LENGTH_SHORT).show();
            }
            return null;
        }

        protected void onPostExecute(Void result) {
            this.progress1.dismiss();
            super.onPostExecute(result);
        }

        protected void onPreExecute() {
            //AppMainActivity.this.listadaptor = new ApplicationAdapter(AppMainActivity.this, R.layout.row, AppMainActivity.this.applist, true);
            this.progress1 = ProgressDialog.show(AppMainActivity.this, null, "Generate Apk File...");
            super.onPreExecute();
        }

        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }

    private class LoApplications extends AsyncTask<Void, Void, Void> {
        private ProgressDialog progress1;

        private LoApplications() {
            this.progress1 = null;
        }

        protected Void doInBackground(Void... params) {
            AppMainActivity.this.listadaptor = new ApplicationAdapter(AppMainActivity.this, R.layout.row, AppMainActivity.this.applist, true);
            AppMainActivity.this.app();
            return null;
        }

        protected void onPostExecute(Void result) {
            this.progress1.dismiss();
            super.onPostExecute(result);
        }

        protected void onPreExecute() {
            AppMainActivity.this.listadaptor = new ApplicationAdapter(AppMainActivity.this, R.layout.row, AppMainActivity.this.applist, true);
            this.progress1 = ProgressDialog.show(AppMainActivity.this, null, "Generate Apk File...");
            super.onPreExecute();
        }

        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }

    private class LoadApplications extends AsyncTask<Void, Void, Void> {
        private ProgressDialog progress;

        private LoadApplications() {
            this.progress = null;
        }

        protected Void doInBackground(Void... params) {
            AppMainActivity.this.applist = AppMainActivity.this.checkForLaunchIntent(AppMainActivity.this.packageManager.getInstalledApplications(128));
            AppMainActivity.this.listadaptor = new ApplicationAdapter(AppMainActivity.this, R.layout.row, AppMainActivity.this.applist, false);
            return null;
        }

        protected void onCancelled() {
            super.onCancelled();
        }

        protected void onPostExecute(Void result) {
            AppMainActivity.this.setListAdapter(AppMainActivity.this.listadaptor);
            this.progress.dismiss();
            super.onPostExecute(result);
        }

        protected void onPreExecute() {
            this.progress = ProgressDialog.show(AppMainActivity.this, null, "Loading application info...");
            super.onPreExecute();
        }

        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app);
        this.btn1 = (Button) findViewById(R.id.button1);
        this.btn1.setTypeface(Typeface.createFromAsset(getAssets(), "nexalight.otf"));
        this.btn1.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                new LoApplications().execute(new Void[0]);
            }
        });
        this.packageManager = getPackageManager();
        new LoadApplications().execute(new Void[0]);
    }

    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        new LoApplications1(position).execute(new Void[0]);
        //ProgressDialog progress1 = ProgressDialog.show(AppMainActivity.this, null, "Generate Apk File...");
       /* try {
            Intent intent = this.packageManager.getLaunchIntentForPackage(((ApplicationInfo) this.applist.get(position)).packageName);
            if (intent != null) {
               intent.addCategory("android.intent.category.LAUNCHER");
                for (ResolveInfo info : getPackageManager().queryIntentActivities(intent, 0)) {
                    File f1 = new File(info.activityInfo.applicationInfo.publicSourceDir);
                    try {
                        String file_name = info.loadLabel(getApplicationContext().getPackageManager()).toString();
                        File f2 = new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "App");
                        f2.mkdirs();
                        File f22 = new File(f2.getPath() + "/" + file_name + ".apk");
                        f22.createNewFile();
                        InputStream in = new FileInputStream(f1);
                        OutputStream out = new FileOutputStream(f22);
                        byte[] buf = new byte[1024];
                        while (true) {
                            int len = in.read(buf);
                            if (len <= 0) {
                                break;
                            }
                            out.write(buf, 0, len);
                        }
                        in.close();
                        out.close();
                        System.out.println("File copied.");
                    } catch (FileNotFoundException ex) {
                        System.out.println(ex.getMessage() + " in the specified directory.");
                    } catch (IOException e) {
                        System.out.println(e.getMessage());
                    }
                }
            }
           // progress1.dismiss();
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        } catch (Exception e2) {
            Toast.makeText(this, e2.getMessage(), Toast.LENGTH_SHORT).show();
        }*/

    }

    public void app() {
        Intent mainIntent = new Intent("android.intent.action.MAIN", null);
        mainIntent.addCategory("android.intent.category.LAUNCHER");
        for (ResolveInfo info : getPackageManager().queryIntentActivities(mainIntent, 0)) {
            File f1 = new File(info.activityInfo.applicationInfo.publicSourceDir);
            try {
                String file_name = info.loadLabel(getApplicationContext().getPackageManager()).toString();
                File f2 = new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "App");
                f2.mkdirs();
                File f22 = new File(f2.getPath() + "/" + file_name + ".apk");
                f22.createNewFile();
                InputStream in = new FileInputStream(f1);
                OutputStream out = new FileOutputStream(f22);
                byte[] buf = new byte[1024];
                while (true) {
                    int len = in.read(buf);
                    if (len <= 0) {
                        break;
                    }
                    out.write(buf, 0, len);
                }
                in.close();
                out.close();
                System.out.println("File copied.");
            } catch (FileNotFoundException ex) {
                System.out.println(ex.getMessage() + " in the specified directory.");
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private List<ApplicationInfo> checkForLaunchIntent(List<ApplicationInfo> list) {
        ArrayList<ApplicationInfo> applist = new ArrayList();
        for (ApplicationInfo info : list) {
            try {
                if (this.packageManager.getLaunchIntentForPackage(info.packageName) != null) {
                    applist.add(info);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return applist;
    }
}
