package com.backup.restore;

public class CallLogsGettersSetters {
    String _date;
    String _duration;
    String _id;
    String _name;
    String _new;
    String _number;
    String _type;

    public String getDate() {
        return this._date;
    }

    public String getDuration() {
        return this._duration;
    }

    public String getId() {
        return this._id;
    }

    public String getName() {
        return this._name;
    }

    public String getNew() {
        return this._new;
    }

    public String getNumber() {
        return this._number;
    }

    public String getType() {
        return this._type;
    }

    public void setDate(String paramString) {
        this._date = paramString;
    }

    public void setDuration(String paramString) {
        this._duration = paramString;
    }

    public void setId(String paramString) {
        this._id = paramString;
    }

    public void setName(String paramString) {
        this._name = paramString;
    }

    public void setNew(String paramString) {
        this._new = paramString;
    }

    public void setNumber(String paramString) {
        this._number = paramString;
    }

    public void setType(String paramString) {
        this._type = paramString;
    }
}
