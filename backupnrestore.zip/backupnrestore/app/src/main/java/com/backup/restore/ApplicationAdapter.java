package com.backup.restore;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.AsyncTask;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class ApplicationAdapter extends ArrayAdapter<ApplicationInfo> {
    private List<ApplicationInfo> appsList = null;
    private Boolean chack;
    private ArrayList<Boolean> checkList = new ArrayList();
    private Context context;
    OnCheckedChangeListener mListener = new OnCheckedChangeListener() {
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                ApplicationAdapter.this.checkList.set(((Integer) buttonView.getTag()).intValue(), Boolean.valueOf(true));
                Toast.makeText(ApplicationAdapter.this.context, "Single Click", Toast.LENGTH_SHORT).show();
                return;
            }
            ApplicationAdapter.this.checkList.set(((Integer) buttonView.getTag()).intValue(), Boolean.valueOf(false));
        }
    };
    private PackageManager packageManager;

    public ApplicationAdapter(Context context, int textViewResourceId, List<ApplicationInfo> appsList, boolean chack) {
        super(context, textViewResourceId, appsList);
        this.context = context;
        this.appsList = appsList;
        this.chack = Boolean.valueOf(chack);
        this.packageManager = context.getPackageManager();
        for (int i = 0; i < appsList.size(); i++) {
            this.checkList.add(Boolean.valueOf(false));
        }
    }

    public int getCount() {
        return this.appsList != null ? this.appsList.size() : 0;
    }

    public ApplicationInfo getItem(int position) {
        return this.appsList != null ? (ApplicationInfo) this.appsList.get(position) : null;
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = ((LayoutInflater) this.context.getSystemService("layout_inflater")).inflate(R.layout.row, null);
        }
        ApplicationInfo data = (ApplicationInfo) this.appsList.get(position);
        if (data != null) {
            TextView packageName = (TextView) view.findViewById(R.id.app_paackage);
            ImageView iconview = (ImageView) view.findViewById(R.id.app_icon);
            ((TextView) view.findViewById(R.id.app_name)).setText(data.loadLabel(this.packageManager));
            packageName.setText(data.packageName);
            iconview.setImageDrawable(data.loadIcon(this.packageManager));

        }
        return view;
    }

}
