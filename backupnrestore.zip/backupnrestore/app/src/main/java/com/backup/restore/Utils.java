package com.backup.restore;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.net.Uri;
import android.os.Environment;
import android.os.StatFs;

public class Utils {
    public static final Uri BOOKMARKS_URI = Uri.parse("content://browser/bookmarks");
    public static void alertDialogShow(Context paramContext, String paramString) {
        final AlertDialog localAlertDialog = new Builder(paramContext).create();
        localAlertDialog.setMessage(paramString);
        localAlertDialog.setTitle(paramContext.getString(R.string.app_name));
        localAlertDialog.setButton(paramContext.getString(R.string.cancel), new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                localAlertDialog.dismiss();
            }
        });
        localAlertDialog.show();
    }

    public static long getFreeSpace() {
        StatFs localStatFs = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
        return ((long) (localStatFs.getBlockSize() * localStatFs.getBlockCount())) / 1048576;
    }

    static boolean isSDcardPresent() {
        return Environment.getExternalStorageState().equals("mounted");
    }
}
