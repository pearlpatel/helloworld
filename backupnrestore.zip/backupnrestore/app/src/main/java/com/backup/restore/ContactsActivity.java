package com.backup.restore;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract.Contacts;
import android.support.v4.content.FileProvider;
import android.text.Html;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.Provider;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import a_vcard.android.syncml.pim.PropertyNode;
import a_vcard.android.syncml.pim.VDataBuilder;
import a_vcard.android.syncml.pim.VNode;
import a_vcard.android.syncml.pim.vcard.VCardException;
import a_vcard.android.syncml.pim.vcard.VCardParser;
import a_vcard.android.syncml.pim.vcard.VCardParser_V21;

public class ContactsActivity extends Activity {
    public static final int RESTORING_CODE = 1;
    public String str;
    Button btnBackup;
    Button btnDeleteAllContacts;
    Button btnRestore;
    Button btnSendToEmail;
    Button btnViewBackups;
    Cursor cursor;
    AlertDialog dismiss;
    int i = 0;
    private int j = 0;
    FileOutputStream localFileOutputStream;
    Iterator localIterator1;
    Iterator localIterator2;
    ProgressDialog pDialog;
    String str1;
    TextView tvLastBackup;
    ArrayList<String> vCard;
    String[] vfile;

    public class DeletingContacsTask extends AsyncTask<Void, Void, Void> {
        public ProgressDialog pd = new ProgressDialog(ContactsActivity.this);

        public DeletingContacsTask(ContactsActivity contactsActivity) {
        }

        protected Void doInBackground(Void[] paramArrayOfVoid) {
            ContactsActivity.this.deleteAllContacts();
            return null;
        }

        protected void onPostExecute(Void paramVoid) {
            super.onPostExecute(paramVoid);
            this.pd.dismiss();
            ((TextView) ContactsActivity.this.findViewById(R.id.tvContacts)).setText(Html.fromHtml("<font color='#FFFFFF'>Contacts:</font>" + ContactsActivity.this.getContactsCount()));
            Toast.makeText(ContactsActivity.this.getApplicationContext(), ContactsActivity.this.getString(R.string.contacts_deleted_successfully_), Toast.LENGTH_SHORT).show();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.pd.setMessage(ContactsActivity.this.getString(R.string.deleting_all_contacts_));
            this.pd.show();
        }
    }

    public class RestoringTask extends AsyncTask<String, Void, Void> {
        ProgressDialog pd = new ProgressDialog(ContactsActivity.this);
        public RestoringTask(ContactsActivity contactsActivity) {
        }
        protected Void doInBackground(String[] paramArrayOfString) {
            Log.e("File", paramArrayOfString[0]);
            ContactsActivity.this.vCardParser(paramArrayOfString[0]);
            return null;
        }

        protected void onPostExecute(Void paramVoid) {
            super.onPostExecute(paramVoid);
            this.pd.dismiss();
        }

        protected void onPreExecute() {
            super.onPreExecute();
           // this.pd.show();
        }
    }

    private void get(Cursor paramCursor) {
        try {
            AssetFileDescriptor localAssetFileDescriptor = getContentResolver().openAssetFileDescriptor(Uri.withAppendedPath(Contacts.CONTENT_VCARD_URI, this.cursor.getString(this.cursor.getColumnIndex("lookup"))), "r");
            byte[] arrayOfByte = new byte[((int) localAssetFileDescriptor.getDeclaredLength())];
            localAssetFileDescriptor.createInputStream().read(arrayOfByte);
            this.vCard.add(new String(arrayOfByte));
        } catch (Exception localException) {
            while (true) {
                localException.printStackTrace();
            }
        }
    }

    private void getVcardString() throws IOException {
        this.vCard = new ArrayList();
        this.cursor = getContentResolver().query(Contacts.CONTENT_URI, null, null, null, null);
        if (this.cursor != null && this.cursor.getCount() > 0) {
            this.localFileOutputStream = new FileOutputStream(Environment.getExternalStorageDirectory().toString() + File.separator + "smsContactsBackups/contacts" + File.separator + this.vfile[0] + ".vcf", false);
            this.cursor.moveToFirst();
            this.i = this.cursor.getCount();
            this.pDialog.setMax(this.i);
            if (this.j >= this.cursor.getCount()) {
                this.localFileOutputStream.close();
                this.cursor.close();
            }
            do {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    public void run() {
                        int k = ContactsActivity.this.j;
                        ContactsActivity.this.pDialog.setProgress(k + 1);
                        Log.d("value is", "" + k);
                        if (k == ContactsActivity.this.i - 1) {
                            Log.d("dismiss", "is called");
                            ContactsActivity.this.pDialog.dismiss();
                            ContactsActivity.this.setBackupDate();
                            ContactsActivity.this.setEmailDialog();
                        }
                    }
                });
                get(this.cursor);
                Log.d("TAG", "Contact " + (this.j + 1) + "VcF String is" + ((String) this.vCard.get(this.j)));
                this.cursor.moveToNext();
                this.localFileOutputStream.write(((String) this.vCard.get(this.j)).toString().getBytes());
                this.j++;
            } while (this.j != this.i);
            this.pDialog.dismiss();
        }
    }

    public void BackupAlert() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.app_name));
        View localView = getLayoutInflater().inflate(R.layout.layout_backup_dialog, null);
        final EditText localEditText = (EditText) localView.findViewById(R.id.etFileName);
        ((TextView) localView.findViewById(R.id.tvBackupLocation)).setText("/storage/sdcard0/smsContactsBackups/contacts");
        localEditText.setText("contacts_" + DateFormat.format("yyMMddhhmmss", new Date().getTime()) + ".vcf");
        localBuilder.setView(localView);
        localBuilder.setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                ContactsActivity.this.vfile = localEditText.getText().toString().trim().split(".vcf");
                ContactsActivity.this.setProgressDialog();
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            Looper.prepare();
                            ContactsActivity.this.getVcardString();
                            Looper.loop();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().alpha = 0.9f;
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        localAlertDialog.show();
    }

    public void deleteAllContactDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setMessage(getString(R.string.are_you_sure_you_wan_to_delete_all_the_contacts_on_the_phone_));
        localBuilder.setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                ContactsActivity.this.panicDialog();
            }
        });
        localBuilder.setNegativeButton("Cancel", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localBuilder.show();
    }

    public void deleteAllContacts() {
        ContentResolver localContentResolver = getContentResolver();
        Cursor localCursor = localContentResolver.query(Contacts.CONTENT_URI, null, null, null, null);
        while (localCursor.moveToNext()) {
            try {
                Uri localUri = Uri.withAppendedPath(Contacts.CONTENT_LOOKUP_URI, localCursor.getString(localCursor.getColumnIndex("lookup")));
                System.out.println("The uri is " + localUri.toString());
                localContentResolver.delete(localUri, null, null);
            } catch (Exception localException) {
                System.out.println(localException.getStackTrace());
            }
        }
    }

    public String getBackupDate(String paramString) {
        return getSharedPreferences("BackupPrefs", 0).getString(paramString, getString(R.string.never_backup));
    }

    public List<FileGetterSetters> getContactFiles() {
        ArrayList localArrayList = new ArrayList();
        for (File localFile : new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + a_vcard.android.provider.Contacts.AUTHORITY).listFiles()) {
            FileGetterSetters localFileGetterSetters = new FileGetterSetters();
            Log.d("file Name is", localFile.getName());
            localFileGetterSetters.setFileName(localFile.getName());
            Date localDate = new Date(localFile.lastModified());
            Log.d("Modified date is", localDate.toString());
            localFileGetterSetters.setDateCreated(localDate.toString());
            localArrayList.add(localFileGetterSetters);
        }
        return localArrayList;
    }

    public int getContactsCount() {
        return managedQuery(Contacts.CONTENT_URI, null, null, null, null).getCount();
    }

    public void initAllViews() {
        this.btnBackup = (Button) findViewById(R.id.btnBackup);
        this.btnRestore = (Button) findViewById(R.id.btnRestore);
        this.btnViewBackups = (Button) findViewById(R.id.btnViewBackup);
        this.btnSendToEmail = (Button) findViewById(R.id.btnSendToEmail);
        this.btnDeleteAllContacts = (Button) findViewById(R.id.btnDeleteAllContacts);
        TextView localTextView1 = (TextView) findViewById(R.id.tvContacts);
        this.tvLastBackup = (TextView) findViewById(R.id.tvLastBackup);
        TextView localTextView2 = (TextView) findViewById(R.id.tvTitle);
        Typeface localTypeface = Typeface.createFromAsset(getAssets(), "nexalight.otf");
        this.btnBackup.setTypeface(localTypeface);
        this.btnRestore.setTypeface(localTypeface);
        this.btnViewBackups.setTypeface(localTypeface);
        this.btnSendToEmail.setTypeface(localTypeface);
        this.btnDeleteAllContacts.setTypeface(localTypeface);
        localTextView2.setTypeface(localTypeface);
        localTextView1.setTypeface(localTypeface);
        this.tvLastBackup.setTypeface(localTypeface);
        this.btnBackup.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (ContactsActivity.this.getContactsCount() > 0) {
                    ContactsActivity.this.BackupAlert();
                } else {
                    Toast.makeText(ContactsActivity.this.getApplicationContext(), "No Contact Found", Toast.LENGTH_SHORT).show();
                }
            }
        });
        this.btnRestore.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ContactsActivity.this.restoreBackupFilesDialog(true);
            }
        });
        this.btnViewBackups.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ContactsActivity.this.showBackupFilesDialog(false);
            }
        });
        this.btnSendToEmail.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ContactsActivity.this.showBackupFilesDialog(true);
            }
        });
        this.btnDeleteAllContacts.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ContactsActivity.this.deleteAllContactDialog();
            }
        });
        localTextView1.setText(Html.fromHtml("<font color='#FFFFFF'>Contacts:</font>" + getContactsCount()));
        this.tvLastBackup.setText(Html.fromHtml("<font color='#FFFFFF'>" + getString(R.string.last_backup) + ":</font>" + getBackupDate("contactBackupDate")));
    }

    public void okDialog() {
        AlertDialog localAlertDialog = new Builder(this).create();
        localAlertDialog.setTitle(getString(R.string.app_name));
        localAlertDialog.setMessage(getString(R.string.deleted_successfully_));
        localAlertDialog.setButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localAlertDialog.show();
    }

    protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
        super.onActivityResult(paramInt1, paramInt2, paramIntent);
        if (paramInt1 == 1) {
            Log.d("result has been called", "yes");
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    ((TextView) ContactsActivity.this.findViewById(R.id.tvContacts)).setText(Html.fromHtml("<font color='#FFFFFF'>Contacts:</font>" + ContactsActivity.this.getContactsCount()));
                }
            }, 10000);
        }
    }

    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setContentView(R.layout.layout_contacts_backup);
        initAllViews();

    }

    public void panicDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.app_name));
        localBuilder.setMessage(getString(R.string.are_you_sure_you_wan_to_delete_all_the_contacts_on_the_phone_));
        localBuilder.setPositiveButton("Sure", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                new DeletingContacsTask(ContactsActivity.this).execute(new Void[0]);
            }
        });
        localBuilder.setNegativeButton("Cancel", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localBuilder.show();
    }

    public void restoreBackupFilesDialog(final boolean paramBoolean) {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.backup_files));
        ListView localListView = new ListView(this);
        final List localList = getContactFiles();
        localListView.setAdapter(new FileAdapter(this, R.layout.item_row_file, localList));
        localListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong) {
                ContactsActivity.this.dismiss.dismiss();
                if (paramBoolean) {
                    String str = Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + a_vcard.android.provider.Contacts.AUTHORITY + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName();
//                    Log.e("file path is", FileProvider.getUriForFile(ContactsActivity.this, BuildConfig.APPLICATION_ID+".provider", new File(str)).toString());
                    //Intent localIntent = new Intent("android.intent.action.VIEW");

                   // localIntent.setDataAndType(FileProvider.getUriForFile(ContactsActivity.this, BuildConfig.APPLICATION_ID+".provider", new File(str)), "text/x-vcard");
                   // localIntent.setDataAndType( FileProvider.getUriForFile(ContactsActivity.this,
                           // BuildConfig.APPLICATION_ID + ".provider",
                           // new File(str)));
                    //localIntent.setDataAndType(Uri.fromFile(new File(str)), "text/x-vcard");
                    //ContactsActivity.this.startActivityForResult(localIntent, 1);
                    new RestoringTask(ContactsActivity.this).execute(new String[]{str});
                }
            }
        });
        localBuilder.setView(localListView);
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().alpha = 0.6f;
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.FileDialogAnimation;
        this.dismiss = localAlertDialog;
        localAlertDialog.show();
    }

    public void sendFileToEmail(String paramString) {
        Intent localIntent = new Intent("android.intent.action.SEND");
        localIntent.setType("message/rfc822");
        localIntent.putExtra("android.intent.extra.EMAIL", new String[0]);
        localIntent.putExtra("android.intent.extra.SUBJECT", "");
        localIntent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + paramString));
        localIntent.putExtra("android.intent.extra.TEXT", "");
        startActivity(Intent.createChooser(localIntent, "Send mail..."));
    }

    public void setBackupDate() {
        CharSequence localCharSequence = DateFormat.format("yy/MM/dd hh:mm:ss", new Date().getTime());
        this.tvLastBackup.setText(Html.fromHtml("<font color='#FFFFFF'>" + getString(R.string.last_backup) + ":</font>" + localCharSequence.toString()));
        setLastBackupDate("contactBackupDate", localCharSequence.toString());
    }

    public void setEmailDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.app_name));
        localBuilder.setCancelable(false);
        localBuilder.setMessage(getString(R.string.send_to_email_backup) + "?");
        localBuilder.setPositiveButton("Back", new OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                Intent inn = new Intent(ContactsActivity.this.getApplicationContext(), MainActivity.class);
                inn.setFlags(67108864);
                ContactsActivity.this.startActivity(inn);
            }
        });
        localBuilder.create().show();
    }

    public void setLastBackupDate(String paramString1, String paramString2) {
        Editor localEditor = getSharedPreferences("BackupPrefs", 0).edit();
        localEditor.putString(paramString1, paramString2);
        localEditor.commit();
    }

    public void setProgressDialog() {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setMessage(getString(R.string.backuping_files_please_wait_));
        this.pDialog.setIndeterminate(false);
        this.pDialog.setProgressDrawable(getResources().getDrawable(R.drawable.greenprogress));
        this.pDialog.setMax(100);
        this.pDialog.setProgressStyle(1);
        this.pDialog.setCancelable(true);
        this.pDialog.show();
    }

    public void showBackupFilesDialog(final boolean paramBoolean) {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.backup_files));
        ListView localListView = new ListView(this);
        final List localList = getContactFiles();
        localListView.setAdapter(new FileAdapter(this, R.layout.item_row_file, localList));
        localListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong) {
                ContactsActivity.this.dismiss.dismiss();
                if (paramBoolean) {
                    ContactsActivity.this.sendFileToEmail(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + a_vcard.android.provider.Contacts.AUTHORITY + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName());
                }
            }
        });
        localBuilder.setView(localListView);
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().alpha = 0.6f;
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.FileDialogAnimation;
        this.dismiss = localAlertDialog;
        localAlertDialog.show();
    }

    public void vCardParser(String paramString) {

        VCardParser localVCardParser = new VCardParser();
        VDataBuilder localVDataBuilder = new VDataBuilder();
        int i = 0;
        File localFile = new File(paramString);
        String localObject = "";

        while (true) {
            try {
                BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(localFile), VCardParser_V21.DEFAULT_CHARSET));
                this.str1 = localBufferedReader.readLine();
                if (this.str1 == null) {
                    Log.e("vCard value is", localObject);
                    localBufferedReader.close();
                    this.j = 0;
                }else{
                    VNode localVNode = (VNode) this.localIterator1.next();
                    i++;
                    String.valueOf(i);
                    this.localIterator2 = localVNode.propList.iterator();
                }
            } catch (IOException e) {
                try {
                    boolean bool = localVCardParser.parse(localObject, VCardParser_V21.DEFAULT_CHARSET, localVDataBuilder);
                    if (this.j == 0) {
                        throw new VCardException("Could not parse vCard file: " + localFile);
                    }
                } catch (VCardException localVCardException2) {
                    localVCardException2.printStackTrace();
                } catch (IOException e2) {
                    VNode localVNode = (VNode) this.localIterator1.next();
                    i++;
                    String.valueOf(i);
                    this.localIterator2 = localVNode.propList.iterator();
                }
            } /*catch (VCardException localVCardException1) {
                localVCardException1.printStackTrace();
            } catch (IOException e22) {
                VNode localVNode2 = (VNode) this.localIterator1.next();
                i++;
                String.valueOf(i);
                this.localIterator2 = localVNode2.propList.iterator();
            }*/

            while (this.localIterator2.hasNext()) {
                PropertyNode localPropertyNode = (PropertyNode) this.localIterator2.next();
                Log.d("prop Name is", localPropertyNode.propName);
                if ("FN".equals(localPropertyNode.propName)) {
                    Log.d("Name is", localPropertyNode.propValue);
                }
                if ("EMAIL".equals(localPropertyNode.propName)) {
                    Log.d("Email is", localPropertyNode.propValue);
                }
            }

            List<VNode> localList = localVDataBuilder.vNodeList;
            localList.size();
            this.localIterator1 = localList.iterator();
            if (!this.localIterator1.hasNext()) {
                localObject = localObject + this.str1 + "\n";
                return;
            }
            while (this.localIterator2.hasNext()) {
                PropertyNode localPropertyNode2 = (PropertyNode) this.localIterator2.next();
                Log.d("prop Name is", localPropertyNode2.propName);
                if ("FN".equals(localPropertyNode2.propName)) {
                    Log.d("Name is", localPropertyNode2.propValue);
                }
                if ("EMAIL".equals(localPropertyNode2.propName)) {
                    Log.d("Email is", localPropertyNode2.propValue);
                }
            }
        }
    }
}
