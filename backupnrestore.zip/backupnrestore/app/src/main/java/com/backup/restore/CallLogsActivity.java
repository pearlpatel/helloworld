package com.backup.restore;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.BaseColumns;
import android.provider.CallLog.Calls;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import android.text.Html;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class CallLogsActivity extends Activity {
    public static final String KEY_DATE = "date";
    public static final String KEY_DURATION = "duration";
    public static final String KEY_ID = "id";
    public static final String KEY_NEW = "new";
    public static final String KEY_NUMBER = "number";
    public static final String KEY_Name = "name";
    public static final String KEY_TYPE = "type";
    public String str;
    Button btnBackup;
    Button btnDeleteAllCallLogs;
    Button btnRestore;
    Button btnSendToEmail;
    Button btnViewBackups;
    AlertDialog dismiss;
    int i;
    int j;
    CallLogsGettersSetters localCallLogsGettersSetters;
    Cursor localCursor;
    ProgressDialog pDialog;
    public List<SMSGettersSetters> smsBuffer = new ArrayList();
    TextView tvLastBackup;
    FileWriter write;
    String[] xmlfile;

    public class DeletingCallLogsTask extends AsyncTask<Void, Void, Void> {
        public ProgressDialog pd = new ProgressDialog(CallLogsActivity.this);

        protected Void doInBackground(Void[] paramArrayOfVoid) {
            CallLogsActivity.this.deleteAllCallLogs();
            return null;
        }

        protected void onPostExecute(Void paramVoid) {
            super.onPostExecute(paramVoid);
            this.pd.dismiss();
            ((TextView) CallLogsActivity.this.findViewById(R.id.tvCallLogs)).setText(Html.fromHtml("<font color='#FFFFFF'>Call Logs:</font>" + CallLogsActivity.this.getCallLogsCount()));
            Toast.makeText(CallLogsActivity.this.getApplicationContext(), CallLogsActivity.this.getString(R.string.call_logs_deleted_successfully_), Toast.LENGTH_SHORT).show();
        }

        @SuppressLint({"NewApi"})
        protected void onPreExecute() {
            super.onPreExecute();
            this.pd.setMessage(CallLogsActivity.this.getString(R.string.deleting_all_call_logs_));
            this.pd.show();
        }
    }

    public class RestoringTask extends AsyncTask<String, Integer, String> {
        ProgressDialog pd = new ProgressDialog(CallLogsActivity.this);

        public RestoringTask(CallLogsActivity callLogsActivity) {
        }

        protected String doInBackground(String[] paramArrayOfString) {
            String str = CallLogsActivity.this.getXML(paramArrayOfString[0]);
            XMLParser localXMLParser = new XMLParser();
            NodeList localNodeList = localXMLParser.getDomElement(str).getElementsByTagName("logs");
            int i = localNodeList.getLength();
            Log.d("total length is", "");
            for (int j = 0; j < i; j++) {
                HashMap localHashMap = new HashMap();
                Element localElement = (Element) localNodeList.item(j);
                localHashMap.put("id", localXMLParser.getValue(localElement, "id"));
                localHashMap.put("number", localXMLParser.getValue(localElement, "number"));
                localHashMap.put("name", localXMLParser.getValue(localElement, "name"));
                localHashMap.put("date", localXMLParser.getValue(localElement, "date"));
                localHashMap.put("type", localXMLParser.getValue(localElement, "type"));
                localHashMap.put(CallLogsActivity.KEY_NEW, localXMLParser.getValue(localElement, CallLogsActivity.KEY_NEW));
                localHashMap.put(CallLogsActivity.KEY_DURATION, localXMLParser.getValue(localElement, CallLogsActivity.KEY_DURATION));
                CallLogsActivity.this.restoreBackup(localHashMap);
                publishProgress(new Integer[]{Integer.valueOf(i), Integer.valueOf(j)});
            }
            return "";
        }

        protected void onPostExecute(String paramString) {
            super.onPostExecute(paramString);
            ((TextView) CallLogsActivity.this.findViewById(R.id.tvCallLogs)).setText(Html.fromHtml("<font color='#FFFFFF'>Call Logs:</font>" + CallLogsActivity.this.getCallLogsCount()));
            this.pd.dismiss();
            CallLogsActivity.this.viewCallLogsDialog();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            this.pd.setProgressStyle(1);
            this.pd.setMessage(CallLogsActivity.this.getString(R.string.restoring_backups_));
            this.pd.setProgressDrawable(CallLogsActivity.this.getResources().getDrawable(R.drawable.greenprogress));
            this.pd.show();
        }

        protected void onProgressUpdate(Integer[] paramArrayOfInteger) {
            this.pd.setMax(paramArrayOfInteger[0].intValue());
            this.pd.setProgress(paramArrayOfInteger[1].intValue());
            super.onProgressUpdate(paramArrayOfInteger);
        }
    }

    private void backupCallLogs() throws IOException {
        this.smsBuffer.clear();
        this.write = new FileWriter((Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "callLogs") + File.separator + this.xmlfile[0] + ".xml");
        Uri localUri = Calls.CONTENT_URI;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        this.localCursor = getContentResolver().query(localUri, new String[]{BaseColumns._ID, "number", "date", "type", "name", KEY_NEW, KEY_DURATION}, null, null, null);
        String[] arrayOfString2 = new String[]{BaseColumns._ID, "number", "date", "type", "name", KEY_NEW, KEY_DURATION};
        this.localCursor.moveToFirst();
        this.i = this.localCursor.getCount();
        this.pDialog.setMax(this.i);
        this.write.append("<?xml version='1.0' encoding='UTF-8'?>");
        this.write.append('\n');
        this.write.append("<alllogs>");
        this.write.append('\n');
        do {
            this.localCallLogsGettersSetters = new CallLogsGettersSetters();
            String str2 = this.localCursor.getString(this.localCursor.getColumnIndex(BaseColumns._ID));
            String str3 = this.localCursor.getString(this.localCursor.getColumnIndex("number"));
            String str4 = this.localCursor.getString(this.localCursor.getColumnIndex("name"));
            String str5 = this.localCursor.getString(this.localCursor.getColumnIndex("date"));
            String str6 = this.localCursor.getString(this.localCursor.getColumnIndex("type"));
            String str7 = this.localCursor.getString(this.localCursor.getColumnIndex(KEY_NEW));
            String str8 = this.localCursor.getString(this.localCursor.getColumnIndex(KEY_DURATION));
            this.localCallLogsGettersSetters.setId(str2);
            this.localCallLogsGettersSetters.setNumber(str3);
            this.localCallLogsGettersSetters.setName(str4);
            this.localCallLogsGettersSetters.setDate(str5);
            this.localCallLogsGettersSetters.setType(str6);
            this.localCallLogsGettersSetters.setNew(str7);
            this.localCallLogsGettersSetters.setDuration(str8);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                public void run() {
                    int m = CallLogsActivity.this.j;
                    CallLogsActivity.this.pDialog.setProgress(m + 1);
                    CallLogsActivity callLogsActivity = CallLogsActivity.this;
                    callLogsActivity.i++;
                    if (m == CallLogsActivity.this.i - 1) {
                        Log.d("dismiss", "is called");
                        CallLogsActivity.this.pDialog.dismiss();
                        CallLogsActivity.this.setBackupDate();
                        CallLogsActivity.this.setEmailDialog();
                    }
                    callLogsActivity = CallLogsActivity.this;
                    callLogsActivity.i--;
                }
            });
            generateXMLFileForCallLogs(this.localCallLogsGettersSetters);
            this.localCursor.moveToNext();
            this.j++;
        } while (this.j != this.i);
        this.write.append("</alllogs>");
        this.write.flush();
        this.write.close();
        this.pDialog.dismiss();
    }

    private void generateXMLFileForCallLogs(CallLogsGettersSetters paramCallLogsGettersSetters) {
        try {
            this.write.append("<logs>");
            this.write.append('\n');
            this.write.append("<id>" + paramCallLogsGettersSetters.getId() + "</id>");
            this.write.append('\n');
            this.write.append("<number>" + paramCallLogsGettersSetters.getNumber() + "</number>");
            this.write.append('\n');
            this.write.append("<name>" + paramCallLogsGettersSetters.getName() + "</name>");
            this.write.append('\n');
            this.write.append("<date>" + paramCallLogsGettersSetters.getDate() + "</date>");
            this.write.append('\n');
            this.write.append("<type>" + paramCallLogsGettersSetters.getType() + "</type>");
            this.write.append('\n');
            this.write.append("<new>" + paramCallLogsGettersSetters.getNew() + "</new>");
            this.write.append('\n');
            this.write.append("<duration>" + paramCallLogsGettersSetters.getDuration() + "</duration>");
            this.write.append('\n');
            this.write.append("</logs>");
            this.write.append('\n');
        } catch (NullPointerException localNullPointerException) {
            while (true) {
                System.out.println("Nullpointer Exception " + localNullPointerException);
            }
        } catch (IOException localIOException) {
            while (true) {
                localIOException.printStackTrace();
            }
        } catch (Exception localException) {
            while (true) {
                localException.printStackTrace();
            }
        }
    }

    @SuppressLint("WrongConstant")
    private void launchComponent(String paramString1, String paramString2) {
        Intent localIntent = new Intent("android.intent.action.MAIN");
        localIntent.addCategory("android.intent.category.LAUNCHER");
        localIntent.setComponent(new ComponentName(paramString1, paramString2));
        localIntent.setFlags(268435456);
        startActivity(localIntent);
    }

    public void BackupAlert() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        View localView = getLayoutInflater().inflate(R.layout.layout_backup_dialog, null);
        final EditText localEditText = (EditText) localView.findViewById(R.id.etFileName);
        ((TextView) localView.findViewById(R.id.tvBackupLocation)).setText("storage/sdcard0/smsContactsBackups/callLogs");
        localEditText.setText("call_logs_" + DateFormat.format("yyMMddhhmmss", new Date().getTime()) + ".xml");
        localBuilder.setView(localView);
        localBuilder.setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                CallLogsActivity.this.xmlfile = localEditText.getText().toString().trim().split(".xml");
                CallLogsActivity.this.setProgressDialog();
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            Looper.prepare();
                            CallLogsActivity.this.backupCallLogs();
                            Looper.loop();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        localAlertDialog.show();
    }

    public void deleteAllCallLogs() {
        Cursor localCursor = getContentResolver().query(Uri.parse("content://call_log/calls/"), null, null, null, null);
        while (localCursor.moveToNext()) {
            try {
                localCursor.getString(0);
                getContentResolver().delete(Uri.parse("content://call_log/calls/"), null, null);
            } catch (Exception e) {
            }
        }
    }

    public void deleteAllCallLogsDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(getString(R.string.app_name));
        localBuilder.setMessage(getString(R.string.are_you_sure_you_wan_to_delete_all_the_call_logs_on_the_phone_));
        localBuilder.setPositiveButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                CallLogsActivity.this.panicDialog();
            }
        });
        localBuilder.setNegativeButton("Cancel", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localBuilder.show();
    }

    public String getBackupDate(String paramString) {
        return getSharedPreferences("BackupPrefs", 0).getString(paramString, getString(R.string.never_backup));
    }

    public int getCallLogsCount() {
        Cursor localCursor = getContentResolver().query(Uri.parse("content://call_log/calls"), null, null, null, null);
        String[] arrayOfString = localCursor.getColumnNames();
        for (String d : arrayOfString) {
            Log.d("Call Logs", d);
        }
        return localCursor.getCount();
    }

    public List<FileGetterSetters> getCallLogsFiles() {
        ArrayList localArrayList = new ArrayList();
        for (File localFile : new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "callLogs").listFiles()) {
            FileGetterSetters localFileGetterSetters = new FileGetterSetters();
            Log.d("file Name is", localFile.getName());
            localFileGetterSetters.setFileName(localFile.getName());
            Date localDate = new Date(localFile.lastModified());
            Log.d("Modified date is", localDate.toString());
            localFileGetterSetters.setDateCreated(localDate.toString());
            localArrayList.add(localFileGetterSetters);
        }
        return localArrayList;
    }

    public String getXML(String paramString) {
        Log.d("File path is", paramString);
        File localFile = new File(paramString);
        StringBuilder localStringBuilder = new StringBuilder();
        try {
            BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(localFile)));
            while (true) {
                String str = localBufferedReader.readLine();
                if (str == null) {
                    return localStringBuilder.toString();
                }
                localStringBuilder.append(str);
                localStringBuilder.append('\n');
            }
        } catch (IOException e) {
            return paramString;
        }
    }

    public void initAllViews() {
        this.btnBackup = (Button) findViewById(R.id.btnBackup);
        this.btnRestore = (Button) findViewById(R.id.btnRestore);
        this.btnViewBackups = (Button) findViewById(R.id.btnViewBackup);
        this.btnSendToEmail = (Button) findViewById(R.id.btnSendToEmail);
        this.btnDeleteAllCallLogs = (Button) findViewById(R.id.btnDeleteAllCallLogs);
        TextView localTextView1 = (TextView) findViewById(R.id.tvCallLogs);
        this.tvLastBackup = (TextView) findViewById(R.id.tvLastBackup);
        TextView localTextView2 = (TextView) findViewById(R.id.tvTitle);
        Typeface localTypeface = Typeface.createFromAsset(getAssets(), "nexalight.otf");
        this.btnBackup.setTypeface(localTypeface);
        this.btnRestore.setTypeface(localTypeface);
        this.btnViewBackups.setTypeface(localTypeface);
        this.btnSendToEmail.setTypeface(localTypeface);
        this.btnDeleteAllCallLogs.setTypeface(localTypeface);
        localTextView2.setTypeface(localTypeface);
        localTextView1.setTypeface(localTypeface);
        this.tvLastBackup.setTypeface(localTypeface);
        this.btnBackup.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (CallLogsActivity.this.getCallLogsCount() > 0) {
                    CallLogsActivity.this.BackupAlert();
                } else {
                    Toast.makeText(CallLogsActivity.this.getApplicationContext(), "No Call Log Found", Toast.LENGTH_SHORT).show();
                }
            }
        });
        this.btnRestore.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CallLogsActivity.this.restoreBackupFilesDialog(true);
            }
        });
        this.btnViewBackups.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CallLogsActivity.this.showBackupFilesDialog(false);
            }
        });
        this.btnSendToEmail.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CallLogsActivity.this.showBackupFilesDialog(true);
            }
        });
        this.btnDeleteAllCallLogs.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CallLogsActivity.this.deleteAllCallLogsDialog();
            }
        });
        localTextView1.setText(Html.fromHtml("<font color='#FFFFFF'>Call Logs:</font>" + getCallLogsCount()));
        this.tvLastBackup.setText(Html.fromHtml("<font color='#FFFFFF'>" + getString(R.string.last_backup) + ":</font>" + getBackupDate("logsBackupDate")));
    }

    public void okDialog() {
        AlertDialog localAlertDialog = new Builder(this).create();
        localAlertDialog.setTitle(getString(R.string.app_name));
        localAlertDialog.setMessage(getString(R.string.deleted_successfully_));
        localAlertDialog.setButton(getString(R.string.OK), new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localAlertDialog.show();
    }

    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setContentView(R.layout.layout_calllogs_backup);
        initAllViews();

    }

    @SuppressLint("WrongConstant")
    public void openInbox() {
        try {
            Intent localIntent = new Intent("android.intent.action.MAIN");
            localIntent.addCategory("android.intent.category.LAUNCHER");
            localIntent.addFlags(AccessibilityEventCompat.TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED);
            for (ResolveInfo localResolveInfo : getPackageManager().queryIntentActivities(localIntent, 0)) {
                if (localResolveInfo.activityInfo.packageName.equalsIgnoreCase("com.android.mms")) {
                    launchComponent(localResolveInfo.activityInfo.packageName, localResolveInfo.activityInfo.name);
                }
            }
        } catch (ActivityNotFoundException e) {
            Toast.makeText(getApplicationContext(), getString(R.string.there_was_a_problem_loading_the_application_) + "com.android.mms", Toast.LENGTH_SHORT).show();
        }
    }

    public void panicDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setIcon(R.drawable.icon_warning);
        localBuilder.setMessage(R.string.are_you_sure_you_wan_to_delete_all_the_call_logs_on_the_phone_);
        localBuilder.setPositiveButton("Sure", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                new DeletingCallLogsTask().execute(new Void[0]);
            }
        });
        localBuilder.setNegativeButton("Cancel", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
            }
        });
        localBuilder.show();
    }

    public void restoreBackup(HashMap<String, String> paramHashMap) {
        ContentValues localContentValues = new ContentValues();
        Log.d("getted id is", "" + ((String) paramHashMap.get("id")));
        Log.d("id", "" + ((String) paramHashMap.get("name")));
        localContentValues.put(BaseColumns._ID, (String) paramHashMap.get("id"));
        localContentValues.put("name", (String) paramHashMap.get("name"));
        localContentValues.put("number", (String) paramHashMap.get("number"));
        localContentValues.put("date", (String) paramHashMap.get("date"));
        localContentValues.put("type", (String) paramHashMap.get("type"));
        localContentValues.put(KEY_NEW, (String) paramHashMap.get(KEY_NEW));
        localContentValues.put(KEY_DURATION, (String) paramHashMap.get(KEY_DURATION));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        getContentResolver().insert(Calls.CONTENT_URI, localContentValues);
    }

    public void restoreBackupFilesDialog(final boolean paramBoolean) {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.backup_files);
        ListView localListView = new ListView(this);
        final List localList = getCallLogsFiles();
        localListView.setAdapter(new FileAdapter(this, R.layout.item_row_file, localList));
        localListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong) {
                CallLogsActivity.this.dismiss.dismiss();
                if (paramBoolean) {
                    Log.d("Seleted file path is", Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "callLogs" + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName());
                    new RestoringTask(CallLogsActivity.this).execute(new String[]{str});
                }
            }
        });
        localBuilder.setView(localListView);
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().alpha = 0.6f;
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.FileDialogAnimation;
        this.dismiss = localAlertDialog;
        localAlertDialog.show();
    }

    public void sendFileToEmail(String paramString) {
        Intent localIntent = new Intent("android.intent.action.SEND");
        localIntent.setType("message/rfc822");
        localIntent.putExtra("android.intent.extra.EMAIL", new String[0]);
        localIntent.putExtra("android.intent.extra.SUBJECT", "");
        localIntent.putExtra("android.intent.extra.STREAM", Uri.parse("file://" + paramString));
        localIntent.putExtra("android.intent.extra.TEXT", "");
        startActivity(Intent.createChooser(localIntent, "Send mail..."));
    }

    public void setBackupDate() {
        CharSequence localCharSequence = DateFormat.format("yy/MM/dd hh:mm:ss", new Date().getTime());
        this.tvLastBackup.setText(Html.fromHtml("<font color='#FFFFFF'>" + getString(R.string.last_backup) + ":</font>" + localCharSequence.toString()));
        setLastBackupDate("logsBackupDate", localCharSequence.toString());
    }

    public void setEmailDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setCancelable(false);
        localBuilder.setMessage(getString(R.string.send_to_email_backup) + "?");
        localBuilder.setPositiveButton("Back", new OnClickListener() {
            @SuppressLint("WrongConstant")
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                Intent inn = new Intent(CallLogsActivity.this.getApplicationContext(), MainActivity.class);
                inn.setFlags(67108864);
                CallLogsActivity.this.startActivity(inn);
            }
        });
        localBuilder.create().show();
    }

    public void setLastBackupDate(String paramString1, String paramString2) {
        Editor localEditor = getSharedPreferences("BackupPrefs", 0).edit();
        localEditor.putString(paramString1, paramString2);
        localEditor.commit();
    }

    public void setProgressDialog() {
        this.pDialog = new ProgressDialog(this);
        this.pDialog.setMessage(getString(R.string.backuping_files_please_wait_));
        this.pDialog.setIndeterminate(false);
        this.pDialog.setProgressDrawable(getResources().getDrawable(R.drawable.greenprogress));
        this.pDialog.setMax(100);
        this.pDialog.setProgressStyle(1);
        this.pDialog.setCancelable(true);
        this.pDialog.show();
    }

    public void showBackupFilesDialog(final boolean paramBoolean) {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.backup_files);
        ListView localListView = new ListView(this);
        final List localList = getCallLogsFiles();
        localListView.setAdapter(new FileAdapter(this, R.layout.item_row_file, localList));
        localListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong) {
                CallLogsActivity.this.dismiss.dismiss();
                if (paramBoolean) {
                    CallLogsActivity.this.sendFileToEmail(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "callLogs" + File.separator + ((FileGetterSetters) localList.get(paramAnonymousInt)).getFileName());
                }
            }
        });
        localBuilder.setView(localListView);
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().alpha = 0.6f;
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.FileDialogAnimation;
        this.dismiss = localAlertDialog;
        localAlertDialog.show();
    }

    public void viewCallLogsDialog() {
        Builder localBuilder = new Builder(this);
        localBuilder.setTitle(R.string.app_name);
        localBuilder.setMessage(getString(R.string.restore_completed_successfully_));
        localBuilder.setPositiveButton("View Call Logs", new OnClickListener() {
            public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt) {
                CallLogsActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("content://call_log/calls")));
            }
        });
        localBuilder.setNegativeButton("Cancel", null);
        AlertDialog localAlertDialog = localBuilder.create();
        localAlertDialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
        localAlertDialog.show();
    }
}
