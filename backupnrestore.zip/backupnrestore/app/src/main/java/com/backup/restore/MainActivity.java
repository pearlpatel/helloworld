package com.backup.restore;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Contacts;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;

public class MainActivity extends Activity {
    Button btnAppBackup;
    Button btnBookmarksBackup;
    Button btnCallLogsBackup;
    Button btnContactBackup;
    Button btnSMSBackup;
    Button ibSettings;
    LinearLayout llStorageBar;
    TextView topText;
    TextView tvFreeSpace;
    TextView tvUsedSpace;
    View vProgress;

    public int barWidth(double paramDouble1, double paramDouble2, int paramInt) {
        return (int) ((((paramDouble2 / (paramDouble1 + paramDouble2)) * 100.0d) * ((double) paramInt)) / 100.0d);
    }

    public void crateStorateDicretories() {
        File localFile1 = new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "sms");
        File localFile2 = new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + Contacts.AUTHORITY);
        File localFile3 = new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "callLogs");
        File localFile4 = new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "App");
        File localFile5 = new File(Environment.getExternalStorageDirectory() + File.separator + "smsContactsBackups" + File.separator + "bookmarks");
        Log.d("sms path is", localFile1.getAbsolutePath());
        if (!localFile1.exists()) {
            localFile1.mkdirs();
        }
        if (!localFile2.exists()) {
            localFile2.mkdirs();
        }
        if (!localFile3.exists()) {
            localFile3.mkdirs();
        }
        if (!localFile4.exists()) {
            localFile4.mkdirs();
        }
        if (!localFile5.exists()) {
            localFile5.mkdirs();
        }
    }

    public double discSpace(String paramString) {
        StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
        return (double) ((stat.getAvailableBlocks() * stat.getBlockSize()) / 1048576);
    }

    public double discSpace1(String paramString) {
        StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getPath());
        return (double) ((statFs.getBlockCount() * statFs.getBlockSize()) / 1048576);
    }

    public void intitViews() {
        this.tvUsedSpace = (TextView) findViewById(R.id.tvUsedSpace);
        this.tvFreeSpace = (TextView) findViewById(R.id.tvFreeSpace);
        this.btnSMSBackup = (Button) findViewById(R.id.btnSMSBackup);
        this.btnBookmarksBackup = (Button) findViewById(R.id.btnBookmarksBackup);
        this.btnAppBackup = (Button) findViewById(R.id.btnappBackup);
        this.btnCallLogsBackup = (Button) findViewById(R.id.btnCallLogsBackup);
        this.btnContactBackup = (Button) findViewById(R.id.btnContactsBackup);
        this.llStorageBar = (LinearLayout) findViewById(R.id.llStorageBar);
       // this.ibSettings = (Button) findViewById(R.id.ibSettings);
        this.topText = (TextView) findViewById(R.id.toptext);
        Typeface localTypeface = Typeface.createFromAsset(getAssets(), "nexalight.otf");
        this.topText.setTypeface(localTypeface);
        this.btnSMSBackup.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, SmsBackupActivity.class));
            }
        });
        this.btnBookmarksBackup.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, BookMarksActivity.class));
            }
        });
        this.btnAppBackup.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, AppMainActivity.class));
            }
        });
        this.btnCallLogsBackup.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, CallLogsActivity.class));
            }
        });
        this.btnContactBackup.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, ContactsActivity.class));
            }
        });
        this.tvUsedSpace.setTypeface(localTypeface);
        this.tvFreeSpace.setTypeface(localTypeface);
        this.btnSMSBackup.setTypeface(localTypeface);
        this.btnBookmarksBackup.setTypeface(localTypeface);
        this.btnAppBackup.setTypeface(localTypeface);
        this.btnCallLogsBackup.setTypeface(localTypeface);
        this.btnContactBackup.setTypeface(localTypeface);
    }

    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        setContentView(R.layout.activity_main);
        intitViews();
        double d1 = discSpace(getString(R.string.free));
        double d2 = discSpace1(getString(R.string.used));
        this.llStorageBar.measure(0, 0);
        if (Utils.isSDcardPresent()) {
            this.tvFreeSpace.setText(Html.fromHtml("<font color='#ffffff'>" + getString(R.string.free) + ":</font>" + (((double) Math.round(d1 * 100.0d)) / 100.0d) + " GB"));
            this.tvUsedSpace.setText(Html.fromHtml("<font color='#ffffff'>" + getString(R.string.storage_used) + ":</font>" + (((double) Math.round(d2 * 100.0d)) / 100.0d) + " GB"));
        }
        this.vProgress = findViewById(R.id.vProgress);
        this.llStorageBar.removeAllViews();
        this.llStorageBar.addView(this.vProgress, new LayoutParams(barWidth(d1, d2, this.llStorageBar.getMeasuredWidth()), 30));
        crateStorateDicretories();

    }

    public void onDestroy() {
        super.onDestroy();
    }


    public void onBackPressed() {
        finish();
        super.onBackPressed();
    }
}
