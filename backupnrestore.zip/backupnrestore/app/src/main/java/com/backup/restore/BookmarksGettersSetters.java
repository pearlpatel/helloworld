package com.backup.restore;

public class BookmarksGettersSetters {
    String _bookmark;
    String _date;
    String _favicon;
    String _id;
    String _thumbnail;
    String _title;
    String _touch_icon;
    String _url;
    String _user_entered;
    String _visits;

    public String getBookmark() {
        return this._bookmark;
    }

    public String getDate() {
        return this._date;
    }

    public String getFavicon() {
        return this._favicon;
    }

    public String getId() {
        return this._id;
    }

    public String getThumbnail() {
        return this._thumbnail;
    }

    public String getTouch_icon() {
        return this._touch_icon;
    }

    public String getUrl() {
        return this._url;
    }

    public String getUser_entered() {
        return this._user_entered;
    }

    public String getVisits() {
        return this._visits;
    }

    public String gettitle() {
        return this._title;
    }

    public void setBookmark(String paramString) {
        this._bookmark = paramString;
    }

    public void setDate(String paramString) {
        this._date = paramString;
    }

    public void setFavicon(String paramString) {
        this._favicon = paramString;
    }

    public void setId(String paramString) {
        this._id = paramString;
    }

    public void setThumbnail(String paramString) {
        this._thumbnail = paramString;
    }

    public void setTouch_icon(String paramString) {
        this._touch_icon = paramString;
    }

    public void setUrl(String paramString) {
        this._url = paramString;
    }

    public void setUser_entered(String paramString) {
        this._user_entered = paramString;
    }

    public void setVisits(String paramString) {
        this._visits = paramString;
    }

    public void settitle(String paramString) {
        this._title = paramString;
    }
}
